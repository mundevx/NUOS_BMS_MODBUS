NUOS C6 LT PANEL MODBUS FIX
============================

Files:
  app_config.c
  device_templates.c
  web_server.c
  modbus_master.c

Use these as replacements for the corresponding current C6 source files.
Do NOT compile device_templates1.c together with device_templates.c; it is a
separate/older duplicate source.

What was fixed
--------------
1. LT Panel is now explicitly:
     Modbus FC04 (Input Registers)
     RAW zero-based PDU addresses:
       Voltage R 0
       Voltage Y 1
       Voltage B 2
       Current R 3
       Current Y 4
       Current B 5
       Apparent Power R 6
       Apparent Power Y 7
       Apparent Power B 8
       Frequency 9
       Power Consumption 10-11
       Power Factor 12

2. add_lt() now treats its address argument as RAW PDU. It no longer passes
   0,1,2,... through the generic 3xxxx/4xxxx conversion.

3. Existing NVS LT configurations using the old addresses
      3029,3031,3033,3035,3037,3039,3067,3069,3071,3125,3131,3161
   are automatically migrated to
      0,1,2,3,4,5,6,7,8,9,10,12
   and forced back to FC04.

4. The previous LT migration that changed FC04 -> FC03 has been removed.

5. Web UI/API displays LT references as the project's 43xxx notation:
      PDU 0 -> 43001
      PDU 29 -> 43030
   and accepts 43001..43999 for LT FC04 when saving.

6. Modbus status for LT also reports the 43xxx reference.

Expected first polling log after flashing
-----------------------------------------
For each LT slave, the first grouped read should be approximately:

  MODBUS: FAST GROUP EP1 FC4 START=0 COUNT=13 ATTRS=12
  MODBUS: TX slave=1 FC4 PDU=0 qty=13
  MODBUS: RX header slave=1 FC=4 byte_count=26

The same pattern should occur for EP2..EP25 with the corresponding slave ID.

If the PowerHud tester is the slave:
  Table: 3x Input Registers
  Function: 04
  Start: 0
  Quantity: 13

The tester must provide data for PDU 0 through PDU 12.

Important
---------
The uploaded source files were inspected and the fix was checked for:
- balanced C braces
- LT attribute count = 12
- LT addresses = 0..9, 10-11, 12
- LT function = FC04
- LT legacy migration present
- LT web reference conversion present

This is a source-level check, not a full ESP-IDF compilation, because the
complete ESP-IDF project/build environment was not included with the upload.
