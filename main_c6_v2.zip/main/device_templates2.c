#include "device_templates.h"
#include <string.h>
#include <stdio.h>

/* The user supplied LT/DG addresses are entered as displayed Modbus references.
 * 3xxxx/4xxxx references are converted to zero-based PDU addresses here. */
static uint16_t pdu(uint32_t ref)
{
    if (ref >= 40001 && ref <= 49999) return (uint16_t)(ref - 40001);
    if (ref >= 30001 && ref <= 39999) return (uint16_t)(ref - 30001);
    if (ref >= 10001 && ref <= 19999) return (uint16_t)(ref - 10001);
    if (ref >= 1 && ref <= 9999) return (uint16_t)(ref - 1);
    return 0;
}

/* LT Panel register map is defined in this firmware as RAW PDU addresses.
 * 0 means the first Input Register, 1 the second, etc.
 * Do NOT pass LT addresses through the generic 3xxxx/4xxxx converter.
 */
static void add_lt(endpoint_config_t *c, const char *name, uint8_t fn,
                   uint16_t pdu_address, uint8_t regs, uint8_t type)
{
    if (c->attribute_count >= APP_MAX_ATTRIBUTES) return;
    modbus_attribute_t *a = &c->attributes[c->attribute_count];
    memset(a, 0, sizeof(*a));
    a->enabled = true;
    a->attribute_id = c->attribute_count;
    a->function = fn;
    a->address = pdu_address;
    a->reg_count = regs;
    a->data_type = type;
    a->word_order = MB_WORD_BIG_FIRST;
    snprintf(a->name, sizeof(a->name), "%s", name);
    c->attribute_count++;
}
static void add(endpoint_config_t *c, const char *name, uint8_t fn, uint32_t ref, uint8_t regs, uint8_t type)
{
    if (c->attribute_count >= APP_MAX_ATTRIBUTES) return;
    modbus_attribute_t *a = &c->attributes[c->attribute_count];
    memset(a, 0, sizeof(*a)); a->enabled=true; a->attribute_id=c->attribute_count;
    a->function=fn; a->address=pdu(ref); a->reg_count=regs; a->data_type=type; a->word_order=MB_WORD_BIG_FIRST;
    snprintf(a->name, sizeof(a->name), "%s", name);
    c->attribute_count++;
}
static void base(endpoint_config_t *c, uint8_t ep, uint8_t dev)
{ memset(c,0,sizeof(*c)); c->enabled=true; c->slave_id=ep; c->device_type=dev; }

static void lt(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_LT_PANEL);
    c->cluster_id = 0xFC10;

    /* LT Panel canonical map: FC04 + zero-based RAW PDU addresses. */
    add_lt(c,"Voltage R",             MB_FC04,  0, 1, MB_TYPE_UINT16);
    add_lt(c,"Voltage Y",             MB_FC04,  1, 1, MB_TYPE_UINT16);
    add_lt(c,"Voltage B",             MB_FC04,  2, 1, MB_TYPE_UINT16);

    add_lt(c,"Current R",             MB_FC04,  3, 1, MB_TYPE_UINT16);
    add_lt(c,"Current Y",             MB_FC04,  4, 1, MB_TYPE_UINT16);
    add_lt(c,"Current B",             MB_FC04,  5, 1, MB_TYPE_UINT16);

    add_lt(c,"Apparent Power R",      MB_FC04,  6, 1, MB_TYPE_UINT16);
    add_lt(c,"Apparent Power Y",      MB_FC04,  7, 1, MB_TYPE_UINT16);
    add_lt(c,"Apparent Power B",      MB_FC04,  8, 1, MB_TYPE_UINT16);

    add_lt(c,"Frequency",              MB_FC04,  9, 1, MB_TYPE_UINT16);
    add_lt(c,"Power Consumption kWh",  MB_FC04, 10, 2, MB_TYPE_UINT32);
    add_lt(c,"Power Factor",           MB_FC04, 12, 1, MB_TYPE_UINT16);
}
static void dg(endpoint_config_t *c, uint8_t ep)
{
    base(c,ep,DEVICE_DG);
    add(c,"Active Fault",3,40012,1,MB_TYPE_UINT16); add(c,"Fault Type",3,40013,1,MB_TYPE_UINT16);
    add(c,"Output Frequency",3,40044,1,MB_TYPE_UINT16); add(c,"Battery Voltage",3,40061,1,MB_TYPE_UINT16); add(c,"Oil Pressure",3,40062,1,MB_TYPE_UINT16);
    add(c,"Coolant Temperature",3,40064,1,MB_TYPE_UINT16); add(c,"Running Status",3,40068,1,MB_TYPE_UINT16);
    add(c,"Output Voltage L-L R",3,40022,1,MB_TYPE_UINT16); add(c,"Output Voltage L-L Y",3,40023,1,MB_TYPE_UINT16); add(c,"Output Voltage L-L B",3,40024,1,MB_TYPE_UINT16);
    add(c,"Output Voltage L-N R",3,40018,1,MB_TYPE_UINT16); add(c,"Output Voltage L-N Y",3,40019,1,MB_TYPE_UINT16); add(c,"Output Voltage L-N B",3,40020,1,MB_TYPE_UINT16);
    add(c,"Current Load R",3,40029,1,MB_TYPE_UINT16); add(c,"Current Load Y",3,40030,1,MB_TYPE_UINT16); add(c,"Current Load B",3,40031,1,MB_TYPE_UINT16);
}
static void ups(endpoint_config_t *c, uint8_t ep)
{
    base(c,ep,DEVICE_UPS);
    /* Initial template is intentionally conservative: these mappings are directly supported by the uploaded UPS register map. */
    add(c,"Input Frequency",4,30004,1,MB_TYPE_UINT16); add(c,"Input Current A",4,30005,1,MB_TYPE_UINT16); add(c,"Input Current B",4,30006,1,MB_TYPE_UINT16); add(c,"Input Current C",4,30007,1,MB_TYPE_UINT16);
    add(c,"Input PF A",4,30008,1,MB_TYPE_UINT16); add(c,"Input PF B",4,30009,1,MB_TYPE_UINT16); add(c,"Input PF C",4,30010,1,MB_TYPE_UINT16);
    add(c,"Output Frequency",4,30014,1,MB_TYPE_UINT16); add(c,"Output Current A",4,30015,1,MB_TYPE_UINT16); add(c,"Output Current B",4,30016,1,MB_TYPE_UINT16); add(c,"Output Current C",4,30017,1,MB_TYPE_UINT16);
    add(c,"Output kW A",4,30018,1,MB_TYPE_UINT16); add(c,"Output kW B",4,30019,1,MB_TYPE_UINT16); add(c,"Output kW C",4,30020,1,MB_TYPE_UINT16);
    add(c,"Load % A",4,30021,1,MB_TYPE_UINT16); add(c,"Load % B",4,30022,1,MB_TYPE_UINT16); add(c,"Load % C",4,30023,1,MB_TYPE_UINT16);
    add(c,"Output kVA A",4,30047,1,MB_TYPE_UINT16); add(c,"Output kVA B",4,30048,1,MB_TYPE_UINT16); add(c,"Output kVA C",4,30049,1,MB_TYPE_UINT16);
    add(c,"Battery Voltage +",4,30031,1,MB_TYPE_UINT16); add(c,"Battery Voltage -",4,30032,1,MB_TYPE_UINT16); add(c,"Battery Temperature",4,30039,1,MB_TYPE_UINT16); add(c,"UPS System Status",4,30071,1,MB_TYPE_UINT16);
    add(c,"Parallel ID",3,40002,1,MB_TYPE_UINT16); add(c,"Number of Parallel UPS",3,40007,1,MB_TYPE_UINT16);
    add(c,"Output Dry Contact",3,40204,1,MB_TYPE_UINT16); add(c,"Input Dry Contact 1",3,40221,1,MB_TYPE_UINT16);
}
static void lift(endpoint_config_t *c, uint8_t ep)
{
    base(c,ep,DEVICE_LIFT);
    /* Uploaded Lift RMS document provides the address words and status-bit meanings.
       Address is supplied as hexadecimal; these are represented as raw register/PDU addresses for editing. */
    static const uint32_t addr[] = {30004,30011,30018,30025,30032,30039,30046};
    uint8_t idx=(ep-1)%7;
    char n[APP_NAME_LEN]; snprintf(n,sizeof(n),"Lift %u status word",(unsigned)(idx+1));
    add(c,n,4,addr[idx],1,MB_TYPE_UINT16);
}

size_t device_template_load(uint8_t device_type, uint8_t endpoint, endpoint_config_t *cfg)
{
    if (!cfg || endpoint==0 || endpoint>APP_MAX_ENDPOINTS) return 0;
    switch(device_type) {
        case DEVICE_LT_PANEL: lt(cfg,endpoint); break;
        case DEVICE_DG: dg(cfg,endpoint); break;
        case DEVICE_UPS: ups(cfg,endpoint); break;
        case DEVICE_LIFT: lift(cfg,endpoint); break;
        default: base(cfg,endpoint,device_type); break;
    }
    return cfg->attribute_count;
}

void device_templates_json(char *out, size_t n)
{
    snprintf(out,n,"[\"LT Panel / Panel MFM\",\"DG\",\"UPS\",\"Lift\",\"Escalator\",\"Fire Hydrant\",\"Anemometer\",\"AC\",\"Ventilation Fan\",\"Custom\"]");
}
