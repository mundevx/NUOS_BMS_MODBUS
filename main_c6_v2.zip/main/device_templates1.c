#include "device_templates.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
static uint16_t pdu(uint32_t ref){if(ref>=40001&&ref<=49999)return(uint16_t)(ref-40001);if(ref>=30001&&ref<=39999)return(uint16_t)(ref-30001);if(ref>=10001&&ref<=19999)return(uint16_t)(ref-10001);if(ref>=1&&ref<=9999)return(uint16_t)(ref-1);return 0;}
static void base(endpoint_config_t*c,uint8_t ep,uint8_t dev,uint16_t cluster){memset(c,0,sizeof(*c));c->enabled=true;c->slave_id=ep;c->device_type=dev;c->cluster_id=cluster;}
static bool grow(endpoint_config_t*c){size_t n=(size_t)c->attribute_count+1;modbus_attribute_t*p=realloc(c->attributes,n*sizeof(*p));if(!p)return false;c->attributes=p;return true;}
static void add(endpoint_config_t*c,const char*name,uint8_t fn,uint32_t ref,uint8_t regs,uint8_t type){if(!grow(c))return;modbus_attribute_t*a=&c->attributes[c->attribute_count];memset(a,0,sizeof(*a));a->enabled=true;a->attribute_id=(uint8_t)c->attribute_count;a->function=fn;a->address=pdu(ref);a->reg_count=regs;a->data_type=type;a->word_order=MB_WORD_BIG_FIRST;snprintf(a->name,sizeof(a->name),"%s",name);c->attribute_count++;}
static void add_packed3(endpoint_config_t*c,const char*name,uint8_t fn,uint16_t a0,uint16_t a1,uint16_t a2){if(!grow(c))return;modbus_attribute_t*a=&c->attributes[c->attribute_count];memset(a,0,sizeof(*a));a->enabled=true;a->attribute_id=(uint8_t)c->attribute_count;a->function=fn;a->address=a0;a->address2=a1;a->address3=a2;a->packed_count=3;a->reg_count=1;a->data_type=MB_TYPE_UINT48;a->word_order=MB_WORD_BIG_FIRST;snprintf(a->name,sizeof(a->name),"%s",name);c->attribute_count++;}
static void lt(endpoint_config_t*c,uint8_t ep){
    base(c,ep,DEVICE_LT_PANEL,0xFC10);
    add(c,"Voltage R",4,43030,1,MB_TYPE_UINT16);
    add(c,"Voltage Y",4,43032,1,MB_TYPE_UINT16);
    add(c,"Voltage B",4,43034,1,MB_TYPE_UINT16);
    add(c,"Current R",4,43036,1,MB_TYPE_UINT16);
    add(c,"Current Y",4,43038,1,MB_TYPE_UINT16);
    add(c,"Current B",4,43040,1,MB_TYPE_UINT16);
    add(c,"Apparent Power R",4,43068,1,MB_TYPE_UINT16);
    add(c,"Apparent Power Y",4,43070,1,MB_TYPE_UINT16);
    add(c,"Apparent Power B",4,43072,1,MB_TYPE_UINT16);
    add(c,"Frequency",4,43132,1,MB_TYPE_UINT16);
    add(c,"Power Consumption kWh",4,43126,2,MB_TYPE_UINT32);
    add(c,"Power Factor",4,43162,1,MB_TYPE_UINT16);
}
static void dg(endpoint_config_t*c,uint8_t ep){base(c,ep,DEVICE_DG,0xFC20);add_packed3(c,"Mains2 Line Voltage RMS R/Y/B",3,1068,1070,1072);add_packed3(c,"Mains Line Voltage RMS R/Y/B",3,1062,1064,1066);add_packed3(c,"Mains Current RMS R/Y/B",3,1078,1080,1082);add_packed3(c,"Generator2 Line Voltage RMS R/Y/B",3,1040,1042,1044);add_packed3(c,"Generator Line Voltage RMS R/Y/B",3,1034,1036,1038);add_packed3(c,"Generator Current RMS R/Y/B",3,1046,1048,1050);add_packed3(c,"Mains Load Watts R/Y/B",3,1085,1087,1089);add_packed3(c,"Generator Load Watts R/Y/B",3,1054,1056,1058);add_packed3(c,"Generator Power R/Y/B",3,1555,1556,1557);add_packed3(c,"Generator Var R/Y/B",3,1547,1549,1551);add_packed3(c,"Generator Positive kWh/kVAh/kVArh",3,1801,1805,1807);}
static void ups(endpoint_config_t*c,uint8_t ep)
{
    /*
     * UPS endpoint model:
     *   Every configured endpoint represents one Modbus slave ID.
     *   Every UPS endpoint has the SAME 28 register attributes.
     *
     * There is NO 16-attribute split here. 16 was only an old template
     * mapping and was never a Zigbee limit.
     */
    base(c,ep,DEVICE_UPS,0xFC30);
    add(c,"Input Frequency",4,30004,1,MB_TYPE_UINT16);
    add(c,"Input Current A",4,30005,1,MB_TYPE_UINT16);
    add(c,"Input Current B",4,30006,1,MB_TYPE_UINT16);
    add(c,"Input Current C",4,30007,1,MB_TYPE_UINT16);
    add(c,"Input PF A",4,30008,1,MB_TYPE_UINT16);
    add(c,"Input PF B",4,30009,1,MB_TYPE_UINT16);
    add(c,"Input PF C",4,30010,1,MB_TYPE_UINT16);
    add(c,"Output Frequency",4,30014,1,MB_TYPE_UINT16);
    add(c,"Output Current A",4,30015,1,MB_TYPE_UINT16);
    add(c,"Output Current B",4,30016,1,MB_TYPE_UINT16);
    add(c,"Output Current C",4,30017,1,MB_TYPE_UINT16);
    add(c,"Output kW A",4,30018,1,MB_TYPE_UINT16);
    add(c,"Output kW B",4,30019,1,MB_TYPE_UINT16);
    add(c,"Output kW C",4,30020,1,MB_TYPE_UINT16);
    add(c,"Load % A",4,30021,1,MB_TYPE_UINT16);
    add(c,"Load % B",4,30022,1,MB_TYPE_UINT16);
    add(c,"Load % C",4,30023,1,MB_TYPE_UINT16);
    add(c,"Output kVA A",4,30047,1,MB_TYPE_UINT16);
    add(c,"Output kVA B",4,30048,1,MB_TYPE_UINT16);
    add(c,"Output kVA C",4,30049,1,MB_TYPE_UINT16);
    add(c,"Battery Voltage +",4,30031,1,MB_TYPE_UINT16);
    add(c,"Battery Voltage -",4,30032,1,MB_TYPE_UINT16);
    add(c,"Battery Temperature",4,30039,1,MB_TYPE_UINT16);
    add(c,"UPS System Status",4,30071,1,MB_TYPE_UINT16);
    add(c,"Parallel ID",3,40002,1,MB_TYPE_UINT16);
    add(c,"Number of Parallel UPS",3,40007,1,MB_TYPE_UINT16);
    add(c,"Output Dry Contact",3,40204,1,MB_TYPE_UINT16);
    add(c,"Input Dry Contact 1",3,40221,1,MB_TYPE_UINT16);
}
static void lift(endpoint_config_t*c,uint8_t ep){
    /* Every Lift endpoint is one Modbus slave.  The endpoint number changes
     * only the slave ID; it must not select a different register. */
    base(c,ep,DEVICE_LIFT,0xFC40);
    static const uint32_t addr[]={30004,30011,30018,30025,30032,30039,30046};
    static const char *name[]={
        "Lift Status Word 1", "Lift Status Word 2", "Lift Status Word 3",
        "Lift Status Word 4", "Lift Status Word 5", "Lift Status Word 6",
        "Lift Status Word 7"
    };
    for(uint8_t i=0;i<7;i++) add(c,name[i],4,addr[i],1,MB_TYPE_UINT16);
}
size_t device_template_load(uint8_t type,uint8_t ep,endpoint_config_t*c){if(!c||ep<1||ep>APP_MAX_ENDPOINTS)return 0;switch(type){case DEVICE_LT_PANEL:lt(c,ep);break;case DEVICE_DG:dg(c,ep);break;case DEVICE_UPS:ups(c,ep);break;case DEVICE_LIFT:lift(c,ep);break;default:base(c,ep,type,0);break;}return c->attribute_count;}
void device_templates_json(char*out,size_t n){snprintf(out,n,"[\"LT Panel / Panel MFM\",\"DG\",\"UPS\",\"Lift\",\"Escalator\",\"Fire Hydrant\",\"Anemometer\",\"AC\",\"Ventilation Fan\",\"Custom\"]");}
