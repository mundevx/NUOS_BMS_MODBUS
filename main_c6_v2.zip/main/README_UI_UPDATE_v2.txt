NUOS C6 UI + Modbus RTU Status Update

Implemented:
1. Endpoint Count is stored in NVS and restored on webpage startup.
2. Removed the top-level Active Endpoint = Modbus Slave ID dropdown.
3. Saved Endpoint cards have Edit, Delete and Status buttons.
4. Status shows the last Modbus RTU cycle for every endpoint.
5. Successful registers show Modbus reference, function and returned data.
6. Failed registers show the read error; the endpoint card becomes red.
7. Endpoint Count change asks:
   Current Enpoints Data will be deleted, Are you Sure to Continue?
   Cancel does not change anything.
8. Continue deletes all current endpoint configuration and recreates exactly
   the selected number of endpoints using the selected Device/Module template.
9. Modbus runtime status is RAM-only; configuration remains in NVS.
10. Modbus tab remains empty.
