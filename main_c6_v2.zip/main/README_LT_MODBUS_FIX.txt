NUOS C6 LT PANEL MODBUS FIX

ROOT CAUSE
LT Panel references such as 43030, 43032, 43068, 43126 and 43162 are 4xxxx Holding Register references. The old firmware configured Function Code 04 (Read Input Registers). It therefore transmitted FC04 requests to addresses derived from the 4xxxx references. The panel returned Modbus exception 0x02 (Illegal Data Address) for every group.

FIX
1. LT Panel template now uses FC03 (Read Holding Registers).
2. The PDU address remains unchanged: 43030 - 40001 = 3029.
3. Existing NVS LT endpoint configurations are automatically migrated from FC04 to FC03 for the known LT map addresses.
4. Existing saved LT template in bms_tpl is automatically migrated too.

EXPECTED REQUEST
Old: [01 04 0B D5 00 0B ...]
New: [01 03 0B D5 00 0B ...]

Expected log:
MODBUS: FAST GROUP EP1 FC3 START=3029 REG=43030 COUNT=11
MODBUS: TX slave=1 FC3 PDU=3029 qty=11 [01 03 0B D5 00 0B CRC_LO CRC_HI]

NO erase-flash is required for this specific mapping fix. The migration updates old NVS entries when they are loaded.
