# C6 – No 16-Attribute Restriction / Correct UPS Endpoint Model

## What was wrong
The previous UPS template was incorrectly split into:
- EP1 = 16 attributes
- EP2 = 12 attributes

That split was a template design mistake, not a Zigbee limitation.

## Correct model
Each endpoint is a Modbus slave ID. Every UPS endpoint uses the complete 28-register attribute set:

1. Input Frequency
2. Input Current A
3. Input Current B
4. Input Current C
5. Input PF A
6. Input PF B
7. Input PF C
8. Output Frequency
9. Output Current A
10. Output Current B
11. Output Current C
12. Output kW A
13. Output kW B
14. Output kW C
15. Load % A
16. Load % B
17. Load % C
18. Output kVA A
19. Output kVA B
20. Output kVA C
21. Battery Voltage +
22. Battery Voltage -
23. Battery Temperature
24. UPS System Status
25. Parallel ID
26. Number of Parallel UPS
27. Output Dry Contact
28. Input Dry Contact 1

EP1 -> slave 1, EP2 -> slave 2, EP3 -> slave 3, etc. The register definitions remain identical; only the Modbus slave ID changes.

## Attribute-count handling
C6 stores attributes dynamically with `uint16_t attribute_count`; there is no compile-time 16-attribute ceiling.
The C6 Zigbee synchronization code iterates the complete configured count and chunks the UART configuration when needed.

The H2 dynamic configuration implementation likewise stores the configured attribute count dynamically and does not define a 16-attribute application limit.

## Compatibility
Known old UPS configurations containing exactly 16 or 12 attributes are migrated automatically to the full 28-attribute UPS template when loaded. Other custom configurations are not overwritten.


Endpoint/attribute model (all device templates):
- Endpoint N is Modbus slave ID N.
- A device template defines the complete register/attribute set for one device type.
- Loading that template for any endpoint uses the same register set; the endpoint number changes only the slave ID.
- No template uses endpoint number to select a subset of attributes.
- The old UPS 16/12 split is migrated to the complete 28-attribute UPS set.
- The old Lift one-register-per-endpoint mapping is migrated to the complete 7-register Lift set.
- C6 attribute storage uses dynamically allocated arrays with a uint16_t attribute_count; there is no compile-time 16-attribute ceiling.
