#include "app_config.h"
#include <esp_log.h>
#include <esp_err.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "nvs.h"
#include "nvs_flash.h"
#include "nuos_link_proto.h"
#include "device_templates.h"

static const char *TAG="APP_CONFIG";
#define NVS_NS "bms_cfg"
#define CFG_MAGIC 0x4E434647u /* NCFG */
#define CFG_VERSION 2u

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint16_t version;
    uint16_t attribute_count;
    uint8_t enabled;
    uint8_t slave_id;
    uint8_t device_type;
    uint16_t cluster_id;
} endpoint_blob_hdr_t;

static const serial_config_t DEFAULT_SERIAL={9600,8,1,0};
static const mqtt_display_config_t DEFAULT_MQTT={"",1883,"","","NUOS-C6","bms/data"};

static esp_err_t get_blob(const char *key,void *dst,size_t len,const void *def){nvs_handle_t h;esp_err_t e=nvs_open(NVS_NS,NVS_READONLY,&h);if(e!=ESP_OK){memcpy(dst,def,len);return ESP_OK;}size_t n=len;e=nvs_get_blob(h,key,dst,&n);nvs_close(h);if(e!=ESP_OK||n!=len)memcpy(dst,def,len);return ESP_OK;}
static esp_err_t set_blob(const char *key,const void *src,size_t len){nvs_handle_t h;esp_err_t e=nvs_open(NVS_NS,NVS_READWRITE,&h);if(e!=ESP_OK)return e;e=nvs_set_blob(h,key,src,len);if(e==ESP_OK)e=nvs_commit(h);nvs_close(h);return e;}

void app_config_free_endpoint(endpoint_config_t *cfg){if(!cfg)return;free(cfg->attributes);cfg->attributes=NULL;cfg->attribute_count=0;}
static void endpoint_default(uint8_t ep,endpoint_config_t *c){memset(c,0,sizeof(*c));c->slave_id=ep;c->device_type=DEVICE_CUSTOM;c->cluster_id=0;}

esp_err_t app_config_init(void){esp_err_t e=nvs_flash_init();if(e==ESP_ERR_NVS_NO_FREE_PAGES||e==ESP_ERR_NVS_NEW_VERSION_FOUND){ESP_ERROR_CHECK(nvs_flash_erase());e=nvs_flash_init();}return e;}
esp_err_t app_config_load_serial(serial_config_t *c){return c?get_blob("serial",c,sizeof(*c),&DEFAULT_SERIAL):ESP_ERR_INVALID_ARG;}
esp_err_t app_config_save_serial(const serial_config_t *c){return c?set_blob("serial",c,sizeof(*c)):ESP_ERR_INVALID_ARG;}


/*
 * One-time compatibility migration for the old UPS split layout.
 *
 * Old firmware could leave:
 *   EP1 = 16 UPS attributes
 *   EP2 = 12 UPS attributes
 *
 * The correct model is now: every UPS endpoint is one Modbus slave and
 * contains the complete 28-register UPS attribute set. This is NOT a
 * Zigbee limit; the template was simply wrong.
 *
 * Only the known old 16/12 split is migrated. Other custom endpoint
 * configurations are left untouched.
 */
static bool s_ups_migration_running = false;
static void migrate_legacy_ups_endpoint_if_needed(uint8_t ep, endpoint_config_t *c)
{
    if (s_ups_migration_running || !c || !c->enabled ||
        c->device_type != DEVICE_UPS || !c->attributes ||
        (c->attribute_count != 16 && c->attribute_count != 12)) {
        return;
    }

    s_ups_migration_running = true;

    endpoint_config_t replacement = {0};
    size_t count = device_template_load(DEVICE_UPS, ep, &replacement);
    if (count == 28 && replacement.attributes) {
        replacement.cluster_id = c->cluster_id ? c->cluster_id : replacement.cluster_id;
        esp_err_t e = app_config_save_endpoint(ep, &replacement);
        if (e == ESP_OK) {
            ESP_LOGW(TAG,
                     "Migrated legacy UPS EP%u: %u attrs -> 28 attrs (same register set for every slave)",
                     ep, c->attribute_count);
            app_config_free_endpoint(c);
            *c = replacement;
            memset(&replacement, 0, sizeof(replacement));
        } else {
            ESP_LOGE(TAG, "UPS EP%u migration save failed: %s", ep, esp_err_to_name(e));
        }
    } else {
        ESP_LOGE(TAG, "UPS EP%u migration failed: could not build 28-attribute template", ep);
    }

    app_config_free_endpoint(&replacement);
    s_ups_migration_running = false;
}

/* Migrate the old Lift template, where the endpoint number selected only
 * one status register.  The endpoint is a Modbus slave instance; every Lift
 * endpoint now receives the complete Lift register set. */
static bool s_lift_migration_running = false;
static void migrate_legacy_lift_endpoint_if_needed(uint8_t ep, endpoint_config_t *c)
{
    if (s_lift_migration_running || !c || !c->enabled ||
        c->device_type != DEVICE_LIFT || !c->attributes ||
        c->attribute_count == 7) {
        return;
    }

    s_lift_migration_running = true;
    endpoint_config_t replacement = {0};
    size_t count = device_template_load(DEVICE_LIFT, ep, &replacement);
    if (count == 7 && replacement.attributes) {
        replacement.cluster_id = c->cluster_id ? c->cluster_id : replacement.cluster_id;
        esp_err_t e = app_config_save_endpoint(ep, &replacement);
        if (e == ESP_OK) {
            ESP_LOGW(TAG,
                     "Migrated legacy Lift EP%u: %u attrs -> 7 attrs (same register set for every slave)",
                     ep, c->attribute_count);
            app_config_free_endpoint(c);
            *c = replacement;
            memset(&replacement, 0, sizeof(replacement));
        } else {
            ESP_LOGE(TAG, "Lift EP%u migration save failed: %s", ep, esp_err_to_name(e));
        }
    } else {
        ESP_LOGE(TAG, "Lift EP%u migration failed: could not build 7-attribute template", ep);
    }
    app_config_free_endpoint(&replacement);
    s_lift_migration_running = false;
}

esp_err_t app_config_load_endpoint(uint8_t ep,endpoint_config_t *c){
    if(!c||ep<1||ep>APP_MAX_ENDPOINTS)return ESP_ERR_INVALID_ARG;
    memset(c,0,sizeof(*c)); endpoint_default(ep,c);
    char key[16];snprintf(key,sizeof(key),"ep%u",ep);
    nvs_handle_t h;esp_err_t e=nvs_open(NVS_NS,NVS_READONLY,&h);if(e!=ESP_OK)return ESP_OK;
    size_t sz=0;e=nvs_get_blob(h,key,NULL,&sz);if(e!=ESP_OK||sz<sizeof(endpoint_blob_hdr_t)){nvs_close(h);return ESP_OK;}
    uint8_t *blob=malloc(sz);if(!blob){nvs_close(h);return ESP_ERR_NO_MEM;}
    size_t got=sz;e=nvs_get_blob(h,key,blob,&got);nvs_close(h);if(e!=ESP_OK){free(blob);return e;}
    endpoint_blob_hdr_t hdr;memcpy(&hdr,blob,sizeof(hdr));
    size_t need=sizeof(hdr)+(size_t)hdr.attribute_count*sizeof(modbus_attribute_t);
    if(hdr.magic!=CFG_MAGIC||hdr.version!=CFG_VERSION||hdr.slave_id!=ep||need!=got){ESP_LOGW(TAG,"EP%u invalid config blob; using defaults",ep);free(blob);return ESP_OK;}
    c->enabled=hdr.enabled!=0;c->slave_id=hdr.slave_id;c->device_type=hdr.device_type;c->cluster_id=hdr.cluster_id;c->attribute_count=hdr.attribute_count;
    if(c->attribute_count){c->attributes=malloc((size_t)c->attribute_count*sizeof(modbus_attribute_t));if(!c->attributes){free(blob);app_config_free_endpoint(c);return ESP_ERR_NO_MEM;}memcpy(c->attributes,blob+sizeof(hdr),(size_t)c->attribute_count*sizeof(modbus_attribute_t));}
    free(blob);
    migrate_legacy_ups_endpoint_if_needed(ep, c);
    migrate_legacy_lift_endpoint_if_needed(ep, c);
    return ESP_OK;
}

esp_err_t app_config_save_endpoint(uint8_t ep,const endpoint_config_t *c){
    if(!c||ep<1||ep>APP_MAX_ENDPOINTS||c->slave_id!=ep)return ESP_ERR_INVALID_ARG;
    if(c->attribute_count && !c->attributes)return ESP_ERR_INVALID_ARG;
    size_t sz=sizeof(endpoint_blob_hdr_t)+(size_t)c->attribute_count*sizeof(modbus_attribute_t);
    uint8_t *blob=calloc(1,sz);if(!blob)return ESP_ERR_NO_MEM;
    endpoint_blob_hdr_t hdr={CFG_MAGIC,CFG_VERSION,c->attribute_count,c->enabled?1:0,c->slave_id,c->device_type,c->cluster_id};
    memcpy(blob,&hdr,sizeof(hdr));if(c->attribute_count)memcpy(blob+sizeof(hdr),c->attributes,(size_t)c->attribute_count*sizeof(modbus_attribute_t));
    char key[16];snprintf(key,sizeof(key),"ep%u",ep);esp_err_t e=set_blob(key,blob,sz);free(blob);return e;
}

esp_err_t app_config_delete_endpoint(uint8_t ep){if(ep<1||ep>APP_MAX_ENDPOINTS)return ESP_ERR_INVALID_ARG;char key[16];snprintf(key,sizeof(key),"ep%u",ep);nvs_handle_t h;esp_err_t e=nvs_open(NVS_NS,NVS_READWRITE,&h);if(e!=ESP_OK)return e;e=nvs_erase_key(h,key);if(e==ESP_OK)e=nvs_commit(h);nvs_close(h);return e==ESP_ERR_NVS_NOT_FOUND?ESP_OK:e;}
esp_err_t app_config_load_mqtt(mqtt_display_config_t *c){return c?get_blob("mqtt",c,sizeof(*c),&DEFAULT_MQTT):ESP_ERR_INVALID_ARG;}
esp_err_t app_config_save_mqtt(const mqtt_display_config_t *c){return c?set_blob("mqtt",c,sizeof(*c)):ESP_ERR_INVALID_ARG;}
esp_err_t app_config_reset_defaults(void){nvs_handle_t h;esp_err_t e=nvs_open(NVS_NS,NVS_READWRITE,&h);if(e!=ESP_OK)return e;e=nvs_erase_all(h);if(e==ESP_OK)e=nvs_commit(h);nvs_close(h);return e;}

esp_err_t app_config_calculate_zigbee_hash(uint32_t *out,uint8_t *eps_out)
{
    if (!out || !eps_out) {
        return ESP_ERR_INVALID_ARG;
    }

    uint32_t crc = 0xFFFFFFFFu;
    uint8_t active = 0;

    for (uint8_t ep = 1; ep <= APP_MAX_ENDPOINTS; ep++) {
        endpoint_config_t c = {0};
        c.slave_id = ep;

        esp_err_t e = app_config_load_endpoint(ep, &c);
        if (e != ESP_OK) {
            app_config_free_endpoint(&c);
            return e;
        }

        uint16_t enabled_count = 0;
        if (c.enabled && c.cluster_id != 0) {
            for (uint16_t i = 0; i < c.attribute_count; i++) {
                if (c.attributes[i].enabled) {
                    enabled_count++;
                }
            }
        }

        /* The endpoint count in ZB_CONFIG_BEGIN must exactly match the
         * endpoints that nuos_uart_link.c will actually transmit. */
        if (enabled_count != 0) {
            active++;
        }

        uint8_t head[8] = {
            ep,
            (enabled_count != 0) ? 1u : 0u,
            c.device_type,
            (uint8_t)c.cluster_id,
            (uint8_t)(c.cluster_id >> 8),
            (uint8_t)enabled_count,
            (uint8_t)(enabled_count >> 8),
            0
        };
        crc = nuos_link_crc32_update(crc, head, sizeof(head));

        /* Hash only the attributes that are actually sent to H2. */
        if (enabled_count != 0) {
            for (uint16_t i = 0; i < c.attribute_count; i++) {
                if (!c.attributes[i].enabled) {
                    continue;
                }
                uint8_t rec[2] = {
                    c.attributes[i].attribute_id,
                    c.attributes[i].data_type
                };
                crc = nuos_link_crc32_update(crc, rec, sizeof(rec));
            }
        }

        app_config_free_endpoint(&c);
    }

    *out = nuos_link_crc32_finish(crc);
    *eps_out = active;
    return ESP_OK;
}

const char *device_type_name(uint8_t t){static const char*n[]={"LT Panel / Panel MFM","DG","UPS","Lift","Escalator","Fire Hydrant","Anemometer","AC","Ventilation Fan","Custom"};return t<DEVICE_COUNT?n[t]:"Custom";}
const char *modbus_data_type_name(uint8_t t){static const char*n[]={"BOOL","UINT16","INT16","UINT32","INT32","FLOAT32","UINT64","INT64","STRING","UINT8","INT8","UINT24_t","UINT48_t"};return t<=MB_TYPE_UINT48?n[t]:"UINT16";}
