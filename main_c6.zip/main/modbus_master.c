#include "modbus_master.h"
#include "app_config.h"
#include "device_templates.h"
#include "nuos_uart_link.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_check.h"
#include "esp_rom_sys.h"

static const char *TAG="MODBUS";
#define RS485_UART UART_NUM_1
#define RS485_TX 3
#define RS485_RX 2
#define RS485_DE 5
#define MB_TIMEOUT_MS 800
#define MB_MAX_REGS 125
#define MB_MAX_BITS 2000
#define POLL_PERIOD_MS 1000

static SemaphoreHandle_t s_bus_mutex;
static serial_config_t s_serial;

static uint16_t crc16(const uint8_t *b,size_t n){uint16_t c=0xFFFF;for(size_t i=0;i<n;i++){c^=b[i];for(int j=0;j<8;j++)c=(c&1)?(c>>1)^0xA001:(c>>1);}return c;}

static uart_parity_t parity_from_cfg(uint8_t p){return p==1?UART_PARITY_ODD:p==2?UART_PARITY_EVEN:UART_PARITY_DISABLE;}

esp_err_t modbus_apply_serial_config(void)
{
    if(app_config_load_serial(&s_serial)!=ESP_OK) return ESP_FAIL;
    uart_config_t c={.baud_rate=(int)s_serial.baud_rate,.data_bits=s_serial.data_bits==7?UART_DATA_7_BITS:UART_DATA_8_BITS,.parity=parity_from_cfg(s_serial.parity),.stop_bits=s_serial.stop_bits==2?UART_STOP_BITS_2:UART_STOP_BITS_1,.flow_ctrl=UART_HW_FLOWCTRL_DISABLE,.source_clk=UART_SCLK_DEFAULT};
    esp_err_t e=uart_param_config(RS485_UART,&c); if(e!=ESP_OK)return e;
    ESP_LOGI(TAG,"RS485 UART1 %lu %u data %u stop parity=%u",(unsigned long)s_serial.baud_rate,s_serial.data_bits,s_serial.stop_bits,s_serial.parity);
    return ESP_OK;
}

static esp_err_t rs485_init(void)
{
    gpio_config_t g={.pin_bit_mask=1ULL<<RS485_DE,.mode=GPIO_MODE_OUTPUT,.pull_up_en=GPIO_PULLUP_DISABLE,.pull_down_en=GPIO_PULLDOWN_DISABLE,.intr_type=GPIO_INTR_DISABLE};
    ESP_RETURN_ON_ERROR(gpio_config(&g),TAG,"DE config"); gpio_set_level(RS485_DE,0);
    ESP_RETURN_ON_ERROR(uart_driver_install(RS485_UART,4096,4096,0,NULL,0),TAG,"uart install");
    ESP_RETURN_ON_ERROR(uart_set_pin(RS485_UART,RS485_TX,RS485_RX,UART_PIN_NO_CHANGE,UART_PIN_NO_CHANGE),TAG,"uart pins");
    return modbus_apply_serial_config();
}

/* Read FC01/02 bits. */
static esp_err_t read_bits(uint8_t slave,uint8_t fc,uint16_t start,uint16_t qty,uint8_t *out,size_t outlen)
{
    if(qty==0||qty>MB_MAX_BITS||outlen<(qty+7)/8)return ESP_ERR_INVALID_ARG;
    uint8_t req[8] = {slave, fc, start >> 8, start & 255, qty >> 8, qty & 255, 0, 0};
    uint16_t c = crc16(req, 6);
    req[6] = c & 255;
    req[7] = c >> 8;
    ESP_LOGI(TAG, "TX slave=%u FC%u PDU=%u qty=%u [%02X %02X %02X %02X %02X %02X %02X %02X]",
             slave, fc, start, qty, req[0], req[1], req[2], req[3],
             req[4], req[5], req[6], req[7]);
    xSemaphoreTake(s_bus_mutex, portMAX_DELAY); uart_flush_input(RS485_UART); gpio_set_level(RS485_DE,1); esp_rom_delay_us(100);
    uart_write_bytes(RS485_UART,req,8); uart_wait_tx_done(RS485_UART,pdMS_TO_TICKS(MB_TIMEOUT_MS)); gpio_set_level(RS485_DE,0);
    uint8_t h[3];
    int n = uart_read_bytes(RS485_UART, h, 3, pdMS_TO_TICKS(MB_TIMEOUT_MS));
    if (n != 3) {
        ESP_LOGW(TAG, "RX timeout waiting for slave=%u FC%u header (%d/3)", slave, fc, n);
        xSemaphoreGive(s_bus_mutex);
        return ESP_ERR_TIMEOUT;
    }
    ESP_LOGI(TAG, "RX header slave=%u FC=%u byte_count_or_exc=%u", h[0], h[1], h[2]);
    if(h[0]!=slave){ESP_LOGW(TAG,"FC%u wrong slave 0x%02X (wanted %u)",fc,h[0],slave);xSemaphoreGive(s_bus_mutex);return ESP_FAIL;}
    if(h[1]&0x80){uint8_t t[2]={0};int tr=uart_read_bytes(RS485_UART,t,2,pdMS_TO_TICKS(100));if(tr==2){uint8_t all[3];
            memcpy(all, h, 3);
            uint16_t rx = t[0] | ((uint16_t)t[1] << 8);
            if (crc16(all, 3) != rx)ESP_LOGW(TAG,"FC%u exception response CRC error",fc);}ESP_LOGW(TAG,"slave %u FC%u exception 0x%02X",slave,fc,h[2]);xSemaphoreGive(s_bus_mutex);return ESP_FAIL;}
    if(h[1]!=(uint8_t)fc){ESP_LOGW(TAG,"FC%u wrong response function 0x%02X",fc,h[1]);xSemaphoreGive(s_bus_mutex);return ESP_FAIL;}
    size_t bytes=h[2]; if(bytes>outlen+2){xSemaphoreGive(s_bus_mutex);return ESP_FAIL;}
    uint8_t buf[MB_MAX_BITS/8+5]; if(bytes+2>sizeof(buf)){xSemaphoreGive(s_bus_mutex);return ESP_ERR_INVALID_SIZE;}
    int r=uart_read_bytes(RS485_UART,buf,bytes+2,pdMS_TO_TICKS(MB_TIMEOUT_MS)); if(r!=(int)bytes+2){xSemaphoreGive(s_bus_mutex);return ESP_ERR_TIMEOUT;}
    uint8_t all[3 + MB_MAX_BITS / 8];
    memcpy(all, h, 3);
    memcpy(all + 3, buf, bytes);
    uint16_t rx = (uint16_t)buf[bytes] | ((uint16_t)buf[bytes + 1] << 8);
    if (crc16(all, 3 + bytes) != rx) {
        ESP_LOGW(TAG, "FC%u CRC error", fc);
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }
    memcpy(out,buf,bytes);xSemaphoreGive(s_bus_mutex);return ESP_OK;
}

/* Read FC03/04. start is zero-based PDU address. */
static esp_err_t read_regs(uint8_t slave, uint8_t fc, uint16_t start,
                           uint16_t qty, uint16_t *out)
{
    if (qty == 0 || qty > MB_MAX_REGS || !out) {
        return ESP_ERR_INVALID_ARG;
    }

    uint8_t req[8] = { slave, fc, start >> 8, start & 255,
                       qty >> 8, qty & 255, 0, 0 };
    uint16_t c = crc16(req, 6);
    req[6] = c & 255;
    req[7] = c >> 8;

    ESP_LOGI(TAG, "TX slave=%u FC%u PDU=%u qty=%u [%02X %02X %02X %02X %02X %02X %02X %02X]",
             slave, fc, start, qty, req[0], req[1], req[2], req[3],
             req[4], req[5], req[6], req[7]);

    xSemaphoreTake(s_bus_mutex, portMAX_DELAY);
    uart_flush_input(RS485_UART);
    gpio_set_level(RS485_DE, 1);
    esp_rom_delay_us(100);
    uart_write_bytes(RS485_UART, req, 8);
    uart_wait_tx_done(RS485_UART, pdMS_TO_TICKS(MB_TIMEOUT_MS));
    gpio_set_level(RS485_DE, 0);

    uint8_t h[3];
    int n = uart_read_bytes(RS485_UART, h, 3, pdMS_TO_TICKS(MB_TIMEOUT_MS));
    if (n != 3) {
        ESP_LOGW(TAG, "RX timeout waiting for slave=%u FC%u header (%d/3)", slave, fc, n);
        xSemaphoreGive(s_bus_mutex);
        return ESP_ERR_TIMEOUT;
    }

    ESP_LOGI(TAG, "RX header slave=%u FC=%u byte_count_or_exc=%u", h[0], h[1], h[2]);

    if (h[0] != slave) {
        ESP_LOGW(TAG, "FC%u wrong slave 0x%02X (wanted %u)", fc, h[0], slave);
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }

    if (h[1] & 0x80) {
        uint8_t t[2] = {0};
        int tr = uart_read_bytes(RS485_UART, t, 2, pdMS_TO_TICKS(100));
        if (tr == 2) {
            uint8_t all[5];
            memcpy(all, h, 3);
            memcpy(all + 3, t, 2);
            uint16_t rx = (uint16_t)t[0] | ((uint16_t)t[1] << 8);
            if (crc16(all, 3) != rx) {
                ESP_LOGW(TAG, "FC%u exception response CRC error", fc);
            }
        }
        ESP_LOGW(TAG, "slave %u FC%u exception 0x%02X", slave, fc, h[2]);
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }

    if (h[1] != fc) {
        ESP_LOGW(TAG, "FC%u wrong response function 0x%02X", fc, h[1]);
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }

    uint16_t bytes = h[2];
    if (bytes != qty * 2 || bytes + 2 > 2 * MB_MAX_REGS + 2) {
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }

    uint8_t body[2 * MB_MAX_REGS + 2];
    int r = uart_read_bytes(RS485_UART, body, bytes + 2,
                            pdMS_TO_TICKS(MB_TIMEOUT_MS));
    if (r != (int)bytes + 2) {
        xSemaphoreGive(s_bus_mutex);
        return ESP_ERR_TIMEOUT;
    }

    uint8_t all[3 + 2 * MB_MAX_REGS];
    memcpy(all, h, 3);
    memcpy(all + 3, body, bytes);
    uint16_t rx = (uint16_t)body[bytes] | ((uint16_t)body[bytes + 1] << 8);
    if (crc16(all, 3 + bytes) != rx) {
        xSemaphoreGive(s_bus_mutex);
        return ESP_FAIL;
    }

    for (uint16_t i = 0; i < qty; i++) {
        out[i] = ((uint16_t)body[2 * i] << 8) | body[2 * i + 1];
    }

    /*
     * Log every successfully received Modbus register value.
     * start is the zero-based PDU address; convert it back to the
     * displayed 3xxxx/4xxxx reference for easier debugging.
     */
    uint32_t ref_base = (fc == MB_FC04) ? 30001u : 40001u;
    for (uint16_t i = 0; i < qty; i++) {
        uint32_t ref = ref_base + start + i;
        ESP_LOGI(TAG,
                 "RX REGISTER slave=%u FC%u REG=%lu PDU=%u VALUE=%u (0x%04X)",
                 slave,
                 fc,
                 (unsigned long)ref,
                 start + i,
                 out[i],
                 out[i]);
    }

    xSemaphoreGive(s_bus_mutex);
    return ESP_OK;
}

static esp_err_t write_single(uint8_t slave,uint8_t fc,uint16_t addr,uint16_t value)
{
    if (fc != 5 && fc != 6) {
        return ESP_ERR_INVALID_ARG;
    }
    uint8_t req[8] = {slave, fc, addr >> 8, addr & 255,
                      value >> 8, value & 255, 0, 0};
    uint16_t c = crc16(req, 6);
    req[6] = c & 255;
    req[7] = c >> 8;
    xSemaphoreTake(s_bus_mutex,portMAX_DELAY);uart_flush_input(RS485_UART);gpio_set_level(RS485_DE,1);esp_rom_delay_us(100);uart_write_bytes(RS485_UART,req,8);uart_wait_tx_done(RS485_UART,pdMS_TO_TICKS(MB_TIMEOUT_MS));gpio_set_level(RS485_DE,0);uint8_t rsp[8];int n=uart_read_bytes(RS485_UART,rsp,8,pdMS_TO_TICKS(MB_TIMEOUT_MS));xSemaphoreGive(s_bus_mutex);if(n!=8)return ESP_ERR_TIMEOUT;if(memcmp(req,rsp,6)!=0)return ESP_FAIL;uint16_t rx=rsp[6]|rsp[7]<<8;return crc16(rsp,6)==rx?ESP_OK:ESP_FAIL;
}

static esp_err_t write_multiple(uint8_t slave,uint8_t fc,uint16_t addr,uint16_t qty,const uint16_t *values)
{
    if((fc!=15&&fc!=16)||qty==0||qty>123||!values)return ESP_ERR_INVALID_ARG;
    uint16_t data_bytes=(fc==15)?(uint16_t)((qty+7)/8):(uint16_t)(qty*2);
    uint16_t len=(uint16_t)(7+data_bytes+2); uint8_t *req=calloc(1,len); if(!req)return ESP_ERR_NO_MEM;
    req[0]=slave;req[1]=fc;req[2]=addr>>8;req[3]=addr&255;req[4]=qty>>8;req[5]=qty&255;req[6]=(uint8_t)data_bytes;
    if(fc==15){for(uint16_t i=0;i<qty;i++)if(values[i])req[7+i/8]|=(uint8_t)(1u<<(i%8));}
    else for(uint16_t i=0;i<qty;i++){req[7+2*i]=values[i]>>8;req[8+2*i]=values[i]&255;}
    uint16_t c=crc16(req,len-2);req[len-2]=c&255;req[len-1]=c>>8;
    xSemaphoreTake(s_bus_mutex,portMAX_DELAY);uart_flush_input(RS485_UART);gpio_set_level(RS485_DE,1);esp_rom_delay_us(100);uart_write_bytes(RS485_UART,req,len);uart_wait_tx_done(RS485_UART,pdMS_TO_TICKS(MB_TIMEOUT_MS));gpio_set_level(RS485_DE,0);
    uint8_t rsp[8];int n=uart_read_bytes(RS485_UART,rsp,8,pdMS_TO_TICKS(MB_TIMEOUT_MS));xSemaphoreGive(s_bus_mutex);free(req);if(n!=8)return ESP_ERR_TIMEOUT;uint16_t rx=rsp[6]|((uint16_t)rsp[7]<<8);return (rsp[0]==slave&&rsp[1]==fc&&crc16(rsp,6)==rx)?ESP_OK:ESP_FAIL;
}

static uint64_t parse_u64(const char *s){return strtoull(s,NULL,0);}
static void encode_value(const modbus_attribute_t *a,const uint16_t *r,uint8_t *dst,size_t *len)
{
    uint64_t v=0; if(a->reg_count==1)v=r[0]; else if(a->reg_count==2){uint32_t x=a->word_order?((uint32_t)r[1]<<16)|r[0]:((uint32_t)r[0]<<16)|r[1];v=x;} else {for(uint8_t i=0;i<a->reg_count&&i<4;i++)v=(v<<16)|r[a->word_order?(a->reg_count-1-i):i];}
    switch(a->data_type){case MB_TYPE_BOOL:dst[0]=(uint8_t)(v?1:0);*len=1;break;case MB_TYPE_UINT16:case MB_TYPE_INT16:dst[0]=v>>8;dst[1]=v;*len=2;break;case MB_TYPE_UINT32:case MB_TYPE_INT32:case MB_TYPE_FLOAT32:dst[0]=v>>24;dst[1]=v>>16;dst[2]=v>>8;dst[3]=v;*len=4;break;default:for(size_t i=0;i<a->reg_count*2;i++)dst[i]=(uint8_t)(v>>(8*(a->reg_count*2-1-i)));*len=a->reg_count*2;break;}
}

static esp_err_t poll_endpoint(const endpoint_config_t *ep)
{
    uint8_t payload[NUOS_LINK_MAX_PAYLOAD];size_t plen=0;/* Generic C6->H2 payload: version, attribute count, then [id,type,len,value]. */
    payload[plen++]=1;payload[plen++]=0;
    uint8_t count=0;
    for(uint8_t i=0;i<ep->attribute_count;i++){
        const modbus_attribute_t *a=&ep->attributes[i];if(!a->enabled)continue;
        uint16_t regs[MB_MAX_REGS]={0};uint8_t bits[MB_MAX_BITS/8+1]={0};esp_err_t e=ESP_FAIL;
        if(a->function==1||a->function==2)e=read_bits(ep->slave_id,a->function,a->address,a->reg_count,bits,sizeof(bits));
        else if(a->function==3||a->function==4)e=read_regs(ep->slave_id,a->function,a->address,a->reg_count,regs);
        else continue; /* write functions are command-only and are not polled */
        if(e!=ESP_OK){
            uint32_t ref = (a->function==MB_FC03||a->function==MB_FC06||a->function==MB_FC16)?40001u+a->address:
                           (a->function==MB_FC04)?30001u+a->address:
                           (a->function==MB_FC02)?10001u+a->address:1u+a->address;
            ESP_LOGW(TAG,"EP%u attr%u %s read failed: FC%u reference=%lu PDU=%u count=%u",
                     ep->slave_id,a->attribute_id,a->name,a->function,(unsigned long)ref,
                     a->address,a->reg_count);
            continue;
        }
        uint8_t value[16];size_t vlen=0;if(a->function==1||a->function==2){uint64_t b=(bits[0])&1;value[0]=(uint8_t)b;vlen=1;}else encode_value(a,regs,value,&vlen);

        /*
         * Attribute-level log: show the configured attribute name and the
         * displayed Modbus register reference alongside the raw register
         * value.  This is especially useful when a packed/multi-register
         * attribute is being encoded for H2.
         */
        if (a->function == MB_FC03 || a->function == MB_FC04) {
            uint32_t ref_base = (a->function == MB_FC04) ? 30001u : 40001u;
            uint32_t ref = ref_base + a->address;
            ESP_LOGI(TAG,
                     "EP%u ATTR%u %s REG=%lu PDU=%u RAW_REG0=%u (0x%04X) encoded_len=%u",
                     ep->slave_id,
                     a->attribute_id,
                     a->name,
                     (unsigned long)ref,
                     a->address,
                     regs[0],
                     regs[0],
                     (unsigned)vlen);
            ESP_LOG_BUFFER_HEX(TAG, value, vlen);
        }

        if (plen + 3u + vlen > sizeof(payload) || count == 255u) {
            ESP_LOGW(TAG, "EP%u runtime payload full; sent %u attributes", ep->slave_id, count);
            break;
        }
        payload[plen++] = a->attribute_id;
        payload[plen++] = a->data_type;
        payload[plen++] = (uint8_t)vlen;
        memcpy(&payload[plen], value, vlen);
        plen += vlen;
        count++;
    }
    payload[1]=count;
    if (count == 0) return ESP_ERR_NOT_FOUND;
    return nuos_link_send_generic(ep->slave_id,payload,(uint16_t)plen);
}

static void poll_task(void *arg)
{
    (void)arg;while(1){for(uint8_t ep=1;ep<=APP_MAX_ENDPOINTS;ep++){endpoint_config_t c;if(app_config_load_endpoint(ep,&c)!=ESP_OK||!c.enabled||c.attribute_count==0)continue;poll_endpoint(&c);vTaskDelay(pdMS_TO_TICKS(5));}vTaskDelay(pdMS_TO_TICKS(POLL_PERIOD_MS));}
}

esp_err_t modbus_write_attribute(uint8_t endpoint,uint8_t attribute_id,const char *value)
{
    endpoint_config_t c;if(app_config_load_endpoint(endpoint,&c)!=ESP_OK)return ESP_FAIL;
    if(attribute_id>=c.attribute_count||!value)return ESP_ERR_NOT_FOUND;
    modbus_attribute_t *a=&c.attributes[attribute_id];if(!a->enabled)return ESP_ERR_INVALID_STATE;
    if(a->function==5||a->function==6){uint16_t v=(uint16_t)parse_u64(value);return write_single(endpoint,a->function,a->address,a->function==5?(v?0xFF00:0):v);}
    if(a->function==15||a->function==16){
        uint16_t vals[123]={0};char *tmp=strdup(value);if(!tmp)return ESP_ERR_NO_MEM;uint16_t n=0;char *save=NULL;for(char *tok=strtok_r(tmp,",",&save);tok&&n<123;tok=strtok_r(NULL,",",&save))vals[n++]=(uint16_t)parse_u64(tok);free(tmp);
        if (n == 0) {
            return ESP_ERR_INVALID_ARG;
        }
        if (a->reg_count && n != a->reg_count) {
            return ESP_ERR_INVALID_ARG;
        }
        return write_multiple(endpoint, a->function, a->address, n, vals);
    }
    return ESP_ERR_NOT_SUPPORTED;
}

esp_err_t modbus_master_init(void){s_bus_mutex=xSemaphoreCreateMutex();if(!s_bus_mutex)return ESP_ERR_NO_MEM;ESP_RETURN_ON_ERROR(rs485_init(),TAG,"RS485 init");xTaskCreate(poll_task,"modbus_poll",8192,NULL,7,NULL);return ESP_OK;}
