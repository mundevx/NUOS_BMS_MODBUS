#ifndef MODBUS_MASTER_H
#define MODBUS_MASTER_H
#include "esp_err.h"
esp_err_t modbus_master_init(void);
esp_err_t modbus_apply_serial_config(void);
esp_err_t modbus_write_attribute(uint8_t endpoint, uint8_t attribute_id, const char *value);
#endif
