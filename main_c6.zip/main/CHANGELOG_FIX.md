# C6 UPS Configuration Synchronization Fix

## Changes

1. UPS template is now split by endpoint:
   - EP1 = 16 attributes
   - EP2 = 12 attributes
   - Cluster remains configuration/template value 0xFC30; H2 does not hard-code it.

2. Zigbee endpoint count hash now counts only endpoints that are actually transferable:
   - enabled
   - non-zero cluster
   - at least one enabled attribute

3. Zigbee hash now hashes only the attributes actually sent to H2.

4. C6 configuration sender now logs each endpoint and chunk.

5. C6 verifies that the number of endpoints actually transmitted equals the BEGIN endpoint count.
   COMMIT is not sent if there is a mismatch.

6. C6 now explicitly logs endpoint-load failures and packing errors instead of silently aborting.

7. UART architecture is unchanged.
8. No H2 attribute maximum is introduced.

## Expected log

ZB_CONFIG: BEGIN hash=... expected_endpoints=2
ZB_CONFIG EP1: ... attrs=16
ZB_CONFIG EP1: sending chunk start=0 count=16 frame_len=40
ZB_CONFIG EP2: ... attrs=12
ZB_CONFIG EP2: sending chunk start=0 count=12 frame_len=32
ZB_CONFIG: all 2 endpoints transmitted; sending COMMIT hash=...
ZB_CONFIG: COMMIT ACKED by H2; waiting for status hash=...


## Additional UPS configuration migration fix
- Added automatic NVS migration for legacy UPS configuration with 28 attributes stored on EP1.
- Legacy EP1 attributes 0..15 are rewritten to EP1; attributes 16..27 are rewritten to EP2.
- EP1/EP2 attribute IDs are renumbered locally from 0.
- Migration occurs only when EP1 is a UPS with exactly 28 attributes and EP2 is empty.
- UPS template save now writes the complete EP1=16 / EP2=12 pair.
- No global Zigbee attribute limit was added.
