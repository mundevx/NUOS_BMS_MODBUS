#include "device_templates.h"
#include <string.h>
#include <stdio.h>

/*
 * NUOS C6 dashboard-aligned device templates
 *
 * Rules:
 *  - Endpoint == Modbus slave ID == Zigbee endpoint.
 *  - Attribute IDs are sequential and stable within each template.
 *  - Do not invent Modbus addresses. LT Panel parameters are configured
 *    and persisted from the web UI; its firmware template is metadata-only.
 *  - DG, UPS, Lift and Escalator templates follow the supplied Modbus maps.
 *  - Device protocol register numbers are stored as zero-based PDU offsets.
 */

#ifndef MB_TYPE_UINT8
#define MB_TYPE_UINT8 9
#endif

static uint16_t pdu(uint32_t ref)
{
    if (ref >= 40001 && ref <= 49999) return (uint16_t)(ref - 40001);
    if (ref >= 30001 && ref <= 39999) return (uint16_t)(ref - 30001);
    if (ref >= 10001 && ref <= 19999) return (uint16_t)(ref - 10001);
    if (ref >= 1 && ref <= 9999) return (uint16_t)(ref - 1);
    return 0;
}

static uint16_t cluster_for_endpoint(uint8_t dev, uint8_t ep)
{
    switch (dev) {
        case DEVICE_LIGHTING:          return 0xFC00;
        case DEVICE_LT_PANEL:          return 0xFC10;
        case DEVICE_DG:                return 0xFC20;
        case DEVICE_UPS:                return (ep == 2) ? 0xFC31 : 0xFC30;
        case DEVICE_LIFT:              return 0xFC40;
        case DEVICE_ESCALATOR:         return 0xFC50;
        case DEVICE_FIRE_HYDRANT:      return 0xFC60;
        case DEVICE_ANEMOMETER:        return 0xFC70;
        case DEVICE_AC:                return 0xFC80;
        case DEVICE_VENTILATION_FAN:   return 0xFC90;
        case DEVICE_SLD:               return 0xFCB0;
        case DEVICE_CUSTOM:            return 0xFCE0;
        default:                       return 0xFCE0;
    }
}

static void base(endpoint_config_t *c, uint8_t ep, uint8_t dev)
{
    memset(c, 0, sizeof(*c));
    c->enabled = true;
    c->slave_id = ep;
    c->device_type = dev;
    c->cluster_id = cluster_for_endpoint(dev, ep);
    c->attributes = calloc(APP_MAX_ATTRIBUTES, sizeof(*c->attributes));
}

static void add_ref(endpoint_config_t *c, const char *name, uint8_t fn,
                    uint32_t ref, uint8_t regs, uint8_t type)
{
    if (!c || c->attribute_count >= APP_MAX_ATTRIBUTES) return;

    modbus_attribute_t *a = &c->attributes[c->attribute_count];
    memset(a, 0, sizeof(*a));

    a->enabled = true;
    a->attribute_id = c->attribute_count;
    a->function = fn;
    a->address = pdu(ref);
    a->reg_count = regs;
    a->data_type = type;
    a->word_order = MB_WORD_BIG_FIRST;
    snprintf(a->name, sizeof(a->name), "%s", name);

    c->attribute_count++;
}

static void add_pdu(endpoint_config_t *c, const char *name, uint8_t fn,
                    uint16_t address, uint8_t regs, uint8_t type)
{
    if (!c || c->attribute_count >= APP_MAX_ATTRIBUTES) return;

    modbus_attribute_t *a = &c->attributes[c->attribute_count];
    memset(a, 0, sizeof(*a));

    a->enabled = true;
    a->attribute_id = c->attribute_count;
    a->function = fn;
    a->address = address;
    a->reg_count = regs;
    a->data_type = type;
    a->word_order = MB_WORD_BIG_FIRST;
    snprintf(a->name, sizeof(a->name), "%s", name);

    c->attribute_count++;
}

/* ----------------------------- LT PANEL -------------------------------- */
/*
 * LT Panel register maps are configured on the web page.  Firmware must not
 * supply a competing hard-coded list of register addresses or attributes.
 * The web editor saves the selected LT Panel attributes as the persistent
 * device template; endpoint provisioning copies that saved template.
 */
static void lt_panel(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_LT_PANEL);
}

/* ----------------------------- DG --------------------------------------- */
/*
 * Dashboard has separate R/Y/B properties, so do NOT pack them into one
 * UINT48 attribute. The supplied DG mapping contains 46 individual
 * parameters. APP_MAX_ATTRIBUTES=64 supports the complete set.
 */
static void dg(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_DG);

    /* Main / Mains measurements */
    add_pdu(c, "Mains Voltage L-L R",       3, 1068, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Voltage L-L Y",       3, 1070, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Voltage L-L B",       3, 1072, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Voltage L-N R",       3, 1062, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Voltage L-N Y",       3, 1064, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Voltage L-N B",       3, 1066, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Current R",           3, 1078, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Current Y",           3, 1080, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Current B",           3, 1082, 2, MB_TYPE_UINT32);
    add_pdu(c, "Mains Frequency",           3, 1060, 1, MB_TYPE_UINT16);
    add_pdu(c, "Mains Earth Current",       3, 1084, 2, MB_TYPE_UINT32);

    /* Generator measurements */
    add_pdu(c, "Generator Voltage L-L R",   3, 1040, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Voltage L-L Y",   3, 1042, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Voltage L-L B",   3, 1044, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Voltage L-N R",   3, 1034, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Voltage L-N Y",   3, 1036, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Voltage L-N B",   3, 1038, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Current R",      3, 1046, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Current Y",      3, 1048, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Current B",      3, 1050, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Frequency",      3, 1032, 1, MB_TYPE_UINT16);
    add_pdu(c, "Generator Earth Current",  3, 1052, 2, MB_TYPE_UINT32);

    /* Power / load measurements */
    add_pdu(c, "Mains Load Watts R",       3, 1085, 2, MB_TYPE_INT32);
    add_pdu(c, "Mains Load Watts Y",       3, 1087, 2, MB_TYPE_INT32);
    add_pdu(c, "Mains Load Watts B",       3, 1089, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Load Watts R",   3, 1054, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Load Watts Y",   3, 1056, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Load Watts B",   3, 1058, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Power Factor R", 3, 1555, 1, MB_TYPE_INT16);
    add_pdu(c, "Generator Power Factor Y", 3, 1556, 1, MB_TYPE_INT16);
    add_pdu(c, "Generator Power Factor B", 3, 1557, 1, MB_TYPE_INT16);
    add_pdu(c, "Generator Average PF",     3, 1558, 1, MB_TYPE_INT16);
    add_pdu(c, "Generator Var R",          3, 1547, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Var Y",          3, 1549, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Var B",          3, 1551, 2, MB_TYPE_INT32);
    add_pdu(c, "Generator Total Var",      3, 1553, 2, MB_TYPE_INT32);

    /* Energy counters */
    add_pdu(c, "Generator Positive kWh",   3, 1801, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Positive kVAh",  3, 1805, 2, MB_TYPE_UINT32);
    add_pdu(c, "Generator Positive kVArh", 3, 1807, 2, MB_TYPE_UINT32);

    /* Engine */
    add_pdu(c, "Engine Speed",             3, 1031, 1, MB_TYPE_UINT16);
    add_pdu(c, "Charge Alternator Voltage",3, 1029, 1, MB_TYPE_UINT16);
    add_pdu(c, "Engine Battery Voltage",   3, 1030, 1, MB_TYPE_UINT16);
    add_pdu(c, "Oil Pressure",             3, 1025, 1, MB_TYPE_UINT16);
    add_pdu(c, "Coolant Temperature",      3, 1026, 1, MB_TYPE_INT16);
    add_pdu(c, "Oil Temperature",          3, 1027, 1, MB_TYPE_INT16);
    add_pdu(c, "Engine Run Hours",         3, 1798, 2, MB_TYPE_UINT32);
    add_pdu(c, "Fuel Level",               3, 1028, 1, MB_TYPE_UINT16);

    /* Additional bus / load values from the supplied DG register map.
       The selected default template stays within APP_MAX_ATTRIBUTES (64). */
    add_pdu(c, "Bus Frequency",            3, 1092, 1, MB_TYPE_UINT16);
    add_pdu(c, "Bus Voltage L-N R",        3, 1093, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Voltage L-N Y",        3, 1095, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Voltage L-N B",        3, 1097, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Voltage L-L R",        3, 1099, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Voltage L-L Y",        3, 1101, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Voltage L-L B",        3, 1103, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Current R",            3, 1105, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Current Y",            3, 1107, 2, MB_TYPE_UINT32);
    add_pdu(c, "Bus Current B",            3, 1109, 2, MB_TYPE_UINT32);
    add_pdu(c, "Load Voltage L-N R",        3, 1263, 2, MB_TYPE_UINT32);
    add_pdu(c, "Load Voltage L-N Y",        3, 1265, 2, MB_TYPE_UINT32);
    add_pdu(c, "Load Voltage L-N B",        3, 1267, 2, MB_TYPE_UINT32);
    add_pdu(c, "Load Frequency",           3, 1275, 1, MB_TYPE_UINT16);
    add_pdu(c, "Generator Phase Rotation",  3, 1074, 1, MB_TYPE_UINT16);
    add_pdu(c, "Mains Phase Rotation",      3, 1075, 1, MB_TYPE_UINT16);
}
/* ----------------------------- UPS -------------------------------------- */
/*
 * UPS protocol:
 *   EP1: telemetry registers 0..56, Function 0x03 (Holding Registers).
 *   EP2: common telesignalization registers 81..114, Function 0x04.
 * Register numbers in the UPS protocol are zero-based PDU addresses.
 */
static void ups_fault_error(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_UPS);

    static const struct {
        const char *name;
        uint16_t address;
    } signals[] = {
        {"Load On Source", 81},
        {"Battery Status", 82},
        {"Battery Connect Status", 83},
        {"Maintain CB Status", 84},
        {"EPO", 85},
        {"Inverter Ready Capacity", 86},
        {"Generator Input", 87},
        {"Input Fail", 88},
        {"Bypass Sequence Fail", 89},
        {"Bypass Voltage Fail", 90},
        {"Bypass Fail", 91},
        {"Bypass Overload", 92},
        {"Bypass Overload Timeout", 93},
        {"Bypass Untrack", 94},
        {"TX Time Limit", 95},
        {"Output Shorted", 96},
        {"Battery EOD", 97},
        {"Battery Test Begin", 98},
        {"Battery Test Result", 99},
        {"Battery Manual Test", 100},
        {"Battery Maintain Result", 101},
        {"Stop Test", 102},
        {"Fault Clear", 103},
        {"History Log Clear", 104},
        {"UPS On Inhibited", 105},
        {"Manual Transfer Bypass", 106},
        {"Battery Voltage Low", 107},
        {"Battery Reverse", 108},
        {"Rectifier Status", 109},
        {"Input Neutral Lost", 110},
        {"Bypass Fan Fail", 111},
        {"Lost N+X Redundant", 112},
        {"EOD System Inhibited", 113},
        {"CT Weld Reverse", 114}
    };

    for (size_t i = 0; i < sizeof(signals) / sizeof(signals[0]); i++) {
        add_pdu(c, signals[i].name, 4, signals[i].address, 1, MB_TYPE_UINT16);
    }
}

static void ups(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_UPS);

    /* Telemetry: protocol register 0 is read with FC03. */
    static const struct {
        const char *name;
        uint16_t address;
        uint8_t type;
    } telemetry[] = {
        {"Bypass Voltage A (compatibility)", 0, MB_TYPE_UINT16},
        {"Bypass Voltage A", 1, MB_TYPE_UINT16},
        {"Bypass Voltage B", 2, MB_TYPE_UINT16},
        {"Bypass Voltage C", 3, MB_TYPE_UINT16},
        {"Bypass Current A", 4, MB_TYPE_UINT16},
        {"Bypass Current B", 5, MB_TYPE_UINT16},
        {"Bypass Current C", 6, MB_TYPE_UINT16},
        {"Bypass Frequency A", 7, MB_TYPE_UINT16},
        {"Bypass Frequency B", 8, MB_TYPE_UINT16},
        {"Bypass Frequency C", 9, MB_TYPE_UINT16},
        {"Bypass PF A", 10, MB_TYPE_UINT16},
        {"Bypass PF B", 11, MB_TYPE_UINT16},
        {"Bypass PF C", 12, MB_TYPE_UINT16},
        {"Input Voltage A", 13, MB_TYPE_UINT16},
        {"Input Voltage B", 14, MB_TYPE_UINT16},
        {"Input Voltage C", 15, MB_TYPE_UINT16},
        {"Input Current A", 16, MB_TYPE_UINT16},
        {"Input Current B", 17, MB_TYPE_UINT16},
        {"Input Current C", 18, MB_TYPE_UINT16},
        {"Input Frequency A", 19, MB_TYPE_UINT16},
        {"Input Frequency B", 20, MB_TYPE_UINT16},
        {"Input Frequency C", 21, MB_TYPE_UINT16},
        {"Input PF A", 22, MB_TYPE_UINT16},
        {"Input PF B", 23, MB_TYPE_UINT16},
        {"Input PF C", 24, MB_TYPE_UINT16},
        {"Output Voltage A", 25, MB_TYPE_UINT16},
        {"Output Voltage B", 26, MB_TYPE_UINT16},
        {"Output Voltage C", 27, MB_TYPE_UINT16},
        {"Output Current A", 28, MB_TYPE_UINT16},
        {"Output Current B", 29, MB_TYPE_UINT16},
        {"Output Current C", 30, MB_TYPE_UINT16},
        {"Output Frequency A", 31, MB_TYPE_UINT16},
        {"Output Frequency B", 32, MB_TYPE_UINT16},
        {"Output Frequency C", 33, MB_TYPE_UINT16},
        {"Output PF A", 34, MB_TYPE_UINT16},
        {"Output PF B", 35, MB_TYPE_UINT16},
        {"Output PF C", 36, MB_TYPE_UINT16},
        {"Output kVA A", 37, MB_TYPE_UINT16},
        {"Output kVA B", 38, MB_TYPE_UINT16},
        {"Output kVA C", 39, MB_TYPE_UINT16},
        {"Output kW A", 40, MB_TYPE_UINT16},
        {"Output kW B", 41, MB_TYPE_UINT16},
        {"Output kW C", 42, MB_TYPE_UINT16},
        {"Output kVar A", 43, MB_TYPE_UINT16},
        {"Output kVar B", 44, MB_TYPE_UINT16},
        {"Output kVar C", 45, MB_TYPE_UINT16},
        {"Load Percentage A", 46, MB_TYPE_UINT16},
        {"Load Percentage B", 47, MB_TYPE_UINT16},
        {"Load Percentage C", 48, MB_TYPE_UINT16},
        {"Environment Temperature", 49, MB_TYPE_UINT16},
        {"Battery Voltage Positive", 50, MB_TYPE_UINT16},
        {"Battery Voltage Negative", 51, MB_TYPE_UINT16},
        {"Battery Current Positive", 52, MB_TYPE_INT16},
        {"Battery Current Negative", 53, MB_TYPE_INT16},
        {"Battery Temperature", 54, MB_TYPE_UINT16},
        {"Battery Remaining Time", 55, MB_TYPE_UINT16},
        {"Battery Capacity", 56, MB_TYPE_UINT16}
    };

    for (size_t i = 0; i < sizeof(telemetry) / sizeof(telemetry[0]); i++) {
        add_pdu(c, telemetry[i].name, 3, telemetry[i].address, 1, telemetry[i].type);
    }
}

/* ----------------------------- LIFT ------------------------------------- */
/*
 * OTIS BMS interface: one Modbus slave (ID 101) exposes five lift status
 * words. The 50001-style references map to PDU offsets 0, 7, 14, 21, 28.
 * Each word carries the documented status bits 0..10.
 */
static void lift(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_LIFT);
    static const uint16_t address[] = {0, 7, 14, 21, 28};
    static const char *name[] = {
        "Lift 1 Status Word", "Lift 2 Status Word", "Lift 3 Status Word",
        "Lift 4 Status Word", "Lift 5 Status Word"
    };
    for (uint8_t i = 0; i < 5; i++)
        add_pdu(c, name[i], 3, address[i], 1, MB_TYPE_UINT16);
}

/* OTIS escalator map: five escalators share one slave and expose three
 * holding-register values per escalator. PDU offsets correspond to the
 * datasheet references 40001/40002/40004, then +7 per escalator. */
static void escalator(endpoint_config_t *c, uint8_t ep)
{
    base(c, ep, DEVICE_ESCALATOR);
    for (uint8_t i = 0; i < 5; i++) {
        uint16_t base_addr = (uint16_t)(i * 7);
        char name[APP_NAME_LEN];
        snprintf(name, sizeof(name), "Escalator %u Status Word", (unsigned)(i + 1));
        add_pdu(c, name, 3, base_addr, 1, MB_TYPE_UINT16);
        snprintf(name, sizeof(name), "Escalator %u Error Code", (unsigned)(i + 1));
        add_pdu(c, name, 3, (uint16_t)(base_addr + 1), 1, MB_TYPE_UINT16);
        snprintf(name, sizeof(name), "Escalator %u Speed", (unsigned)(i + 1));
        add_pdu(c, name, 3, (uint16_t)(base_addr + 3), 2, MB_TYPE_UINT32);
    }
}

/*
 * The following dashboard modules have a parameter list, but the supplied
 * C6 source does not contain a corresponding Modbus register map. Do not
 * create fake register addresses. The web endpoint editor remains the
 * authoritative source for these modules until their register maps are
 * supplied.
 */
static void dashboard_config_only(endpoint_config_t *c, uint8_t ep, uint8_t dev)
{
    base(c, ep, dev);
}

size_t device_template_load(uint8_t device_type, uint8_t endpoint,
                            endpoint_config_t *cfg)
{
    if (!cfg || endpoint == 0 || endpoint > APP_MAX_ENDPOINTS) return 0;

    switch (device_type) {
        case DEVICE_LT_PANEL:
            lt_panel(cfg, endpoint);
            break;

        case DEVICE_DG:
            dg(cfg, endpoint);
            break;

        case DEVICE_UPS:
            if (endpoint == 2) ups_fault_error(cfg, endpoint);
            else ups(cfg, endpoint);
            break;

        case DEVICE_LIFT:
            lift(cfg, endpoint);
            break;

        case DEVICE_ESCALATOR:
            escalator(cfg, endpoint);
            break;

        case DEVICE_FIRE_HYDRANT:
        case DEVICE_ANEMOMETER:
        case DEVICE_AC:
        case DEVICE_VENTILATION_FAN:
        case DEVICE_SLD:
        case DEVICE_LIGHTING:
        case DEVICE_CUSTOM:
        default:
            dashboard_config_only(cfg, endpoint, device_type);
            break;
    }

    return cfg->attribute_count;
}

void device_templates_json(char *out, size_t n)
{
    snprintf(out, n,
        "["
        "\"LT Panel / Panel MFM\","
        "\"DG\","
        "\"UPS\","
        "\"Lift\","
        "\"Escalator\","
        "\"Fire Hydrant\","
        "\"Anemometer\","
        "\"AC\","
        "\"Ventilation Fan\","
        "\"Custom\","
        "\"SLD\","
        "\"Lighting\""
        "]");
}
